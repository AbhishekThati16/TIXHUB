import * as bcrypt from 'bcrypt';
import { JwtService } from '@nestjs/jwt';

export class AuthService {
  constructor(
    private jwtService: JwtService,
    private prisma: any,
  ) {}

  async register(data: any) {
    const hashed = await bcrypt.hash(data.password, 10);

    const user = await this.prisma.user.create({
      data: {
        username: data.username,
        email: data.email,
        password: hashed,
      },
    });

    return {
      token: this.jwtService.sign({
        id: user.id,
        email: user.email,
      }),
    };
  }

  async login(data: any) {
    const user = await this.prisma.user.findUnique({
      where: { email: data.email },
    });

    if (!user) {
      throw new Error('User not found');
    }

    const valid = await bcrypt.compare(
      data.password,
      user.password,
    );

    if (!valid) {
      throw new Error('Invalid password');
    }

    return {
      token: this.jwtService.sign({
        id: user.id,
        email: user.email,
      }),
    };
  }
}
