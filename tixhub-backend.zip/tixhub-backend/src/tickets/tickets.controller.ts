import {
  Controller,
  Get,
  Post,
  Body,
  Param,
} from '@nestjs/common';

@Controller('tickets')
export class TicketsController {
  constructor(
    private readonly ticketsService: any,
  ) {}

  @Get()
  async getTickets() {
    return this.ticketsService.getAllTickets();
  }

  @Post()
  async createTicket(@Body() body: any) {
    return this.ticketsService.createTicket(body);
  }

  @Get(':id')
  async getTicket(@Param('id') id: string) {
    return this.ticketsService.getTicket(id);
  }
}
