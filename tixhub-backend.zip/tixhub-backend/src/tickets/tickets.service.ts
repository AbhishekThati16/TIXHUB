export class TicketsService {
  constructor(private prisma: any) {}

  async getAllTickets() {
    return this.prisma.ticket.findMany({
      include: {
        seller: true,
        bids: true,
      },
    });
  }

  async createTicket(data: any) {
    return this.prisma.ticket.create({
      data,
    });
  }

  async getTicket(id: string) {
    return this.prisma.ticket.findUnique({
      where: { id },
      include: {
        seller: true,
        bids: true,
      },
    });
  }
}
