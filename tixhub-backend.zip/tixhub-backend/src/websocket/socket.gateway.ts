import {
  WebSocketGateway,
  SubscribeMessage,
  MessageBody,
  WebSocketServer,
} from '@nestjs/websockets';

import { Server } from 'socket.io';

@WebSocketGateway({
  cors: true,
})
export class SocketGateway {
  @WebSocketServer()
  server: Server;

  @SubscribeMessage('newBid')
  handleBid(@MessageBody() data: any) {

    this.server.emit('bidUpdated', {
      ticketId: data.ticketId,
      amount: data.amount,
    });

    return data;
  }
}
