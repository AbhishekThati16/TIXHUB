export class PriceService {

  async suggestPrice(event: string) {

    const basePrice = Math.floor(
      Math.random() * 10000,
    ) + 5000;

    return {
      recommended: basePrice,
      min: basePrice - 1000,
      max: basePrice + 3000,
    };
  }
}
